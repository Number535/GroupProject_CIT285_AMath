package ProjectResources.PlayTiles;

// PlusOrMinusTile
// Programmer: Easy Group
// Last Modified: 10/6/16

public class PlusOrMinusTile extends PlayTile {

    public PlusOrMinusTile() {
        setTileImage("Resource/+or-.png");
    }
}
