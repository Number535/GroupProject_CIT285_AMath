package ProjectResources.PlayTiles;

// DivideTile
// 
// Programmer: Easy Group
// Last Modified: 10/6/16
public class DivideTile extends OperatorTile {
    public DivideTile() {
        sign = '/';
        setTileImage("Resource/divide.png");
    }
}
