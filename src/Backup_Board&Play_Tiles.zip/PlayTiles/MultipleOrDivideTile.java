package ProjectResources.PlayTiles;

// MultipleOrDivideTile
// 
// Programmer: Easy Group
// Last Modified: 10/6/16
public class MultipleOrDivideTile extends PlayTile {

    public MultipleOrDivideTile() {
        setTileImage("Resource/multipleOrDivide.png");
    }

}
