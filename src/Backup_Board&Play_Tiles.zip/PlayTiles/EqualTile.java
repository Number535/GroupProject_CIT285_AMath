package ProjectResources.PlayTiles;

// EqualTile
// 
// Programmer: Easy Group
// Last Modified: 10/6/16
public class EqualTile extends OperatorTile {

    public EqualTile() {
        sign = '=';
        setTileImage("Resource/=.png");
    }
}
