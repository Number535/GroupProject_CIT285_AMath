package ProjectResources.BoardTiles;

import ProjectResources.PlayTiles.PlayTile;
import javafx.scene.image.Image;

// BoardTile
// Programmer: Easy Group
// Last Modified: 9/23/16


public abstract class BoardTile {
    protected int x;
    protected int y;
    protected PlayTile playTile;
    protected boolean isPlaced;
    protected Image tileImage;

    public BoardTile() {
        this.x = -1;
        this.y = -1;
        this.playTile = null;
        this.isPlaced = false;
        this.tileImage = null;
    }

    public BoardTile(int x, int y, PlayTile playTile, boolean isPlaced, String tileImageUrl) {
        this.x = x;
        this.y = y;
        this.playTile = playTile;
        this.isPlaced = isPlaced;
        this.tileImage = new Image(getClass().getResourceAsStream(tileImageUrl));
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public PlayTile getPlayTile() {
        return playTile;
    }

    public boolean isPlaced() {
        return isPlaced;
    }

    public Image getTileImage() {
        return tileImage;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setPlayTile(PlayTile playTile) {
        this.playTile = playTile;
    }

    public void setPlaced(boolean placed) {
        isPlaced = placed;
    }

    public void setTileImage(String tileImageUrl) {
        this.tileImage = new Image(getClass().getResourceAsStream(tileImageUrl));
    }

    public abstract int getScore();

    public void displayLocation() {
        System.out.printf("[%d, %d] ", getX(), getY());
    }
}
