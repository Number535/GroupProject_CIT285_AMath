package ProjectResources.BoardTiles;

import ProjectResources.BoardTiles.BoardTile;

// TripleBoardTile
// 
// Programmer: Easy Group
// Last Modified: 9/23/16
public class TripleBoardTile extends BoardTile {
    @Override
    public int getScore() {
        return playTile.getScore()*3;
    }
}
