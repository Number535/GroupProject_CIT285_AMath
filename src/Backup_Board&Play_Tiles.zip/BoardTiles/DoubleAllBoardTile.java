package ProjectResources.BoardTiles;

import ProjectResources.BoardTiles.BoardTile;

// DoubleAllBoardTile
// 
// Programmer: Easy Group
// Last Modified: 9/23/16
public class DoubleAllBoardTile extends BoardTile {
    int totalScore = -1;

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getScore() {
        return (2 * totalScore);
    }
}
