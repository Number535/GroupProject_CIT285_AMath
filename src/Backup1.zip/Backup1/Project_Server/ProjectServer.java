package Project_Server;
// ProjectServer
// 
// Programmer: Prakrit Saetang
// Last Modified: 9/24/16

import ProjectResources.AMathConstants;
import ProjectResources.CommunicatePackage;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

public class ProjectServer extends Application implements AMathConstants {
    private ServerSocket serverSocket;
    private Socket player1;
    private Socket player2;
    private ObjectOutputStream outP1;
    private ObjectOutputStream outP2;
    private ObjectInputStream inP1;
    private ObjectInputStream inP2;
    private DataInputStream inP1Data;
    private DataInputStream inP2Data;
    private DataOutputStream outP1Data;
    private DataOutputStream outP2Data;

    TextArea taLog = new TextArea();
    private boolean isConnected;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void stop() throws Exception {
        super.stop();
    }

    @Override
    public void start(Stage primaryStage) {

        // Create a scene and place it in the stage
        Scene scene = new Scene(new ScrollPane(taLog), 500, 250);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Project Server");
        primaryStage.show();

        isConnected = false;

        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(2705);
                Platform.runLater(() -> {
                    taLog.appendText(new Date() + ": Server started at socket 2705\n");
                });

                Platform.runLater(() -> {
                    taLog.appendText(new Date() + ": Waiting for players to join\n");
                });

                player1 = serverSocket.accept();
                Platform.runLater(() -> {
                    taLog.appendText(new Date() + ": player1 " + player1.getInetAddress().getHostAddress() + " joined\n");
                });


                outP1 = new ObjectOutputStream(player1.getOutputStream());
                outP1Data = new DataOutputStream(player1.getOutputStream());
                outP1Data.writeInt(AMathConstants.PLAYER1);
                outP1.flush();

                inP1 = new ObjectInputStream(player1.getInputStream());
                Platform.runLater(() -> {
                    taLog.appendText("Stream for player1 is set up..\n");
                });

                outP1.writeObject("You are player 1");
                outP1.flush();

                outP1.writeObject("Wait for player 2 to join...");
                outP1.flush();


                player2 = serverSocket.accept();
                Platform.runLater(() -> {
                    taLog.appendText(new Date() + ": player2 " + player2.getInetAddress().getHostAddress() + " joined\n");
                });

                outP2 = new ObjectOutputStream(player2.getOutputStream());
                outP2Data = new DataOutputStream(player2.getOutputStream());
                outP2Data.writeInt(AMathConstants.PLAYER2);
                outP2.flush();
                inP2 = new ObjectInputStream(player2.getInputStream());
                Platform.runLater(() -> {
                    taLog.appendText("Stream for player2 is set up..\n");
                });

                outP2.writeObject("you are player 2");
                outP2.flush();

                isConnected = true;

                CommunicatePackage communicatePackage = (CommunicatePackage) inP1.readObject();
                System.out.println("read Package");
                outP2.writeObject(communicatePackage);
                System.out.println("write Package");

                outP1.writeObject("Game started...");
                outP2.writeObject("Game started...");

                new Thread(new Chatting(inP1, outP2, player1.getInetAddress().getHostAddress())).start();
                new Thread(new Chatting(inP2, outP1, player2.getInetAddress().getHostAddress())).start();

            }
            catch (Exception ex) {

            }
        }).start();
    }

    class Chatting implements Runnable {

        private ObjectInputStream chatInputStream;
        private ObjectOutputStream chatOutputStream;
        private String ip;

        Chatting(ObjectInputStream inP1, ObjectOutputStream outP2, String inputIP) {
            this.chatInputStream = inP1;
            this.chatOutputStream = outP2;
            this.ip = inputIP;
        }

        @Override
        public void run() {
            while (isConnected) {
                try {
                    String message = chatInputStream.readObject().toString();
                    System.out.println("Receive: " +  message);
                    chatOutputStream.writeObject(ip + ": " + message);
                    System.out.println("Write: " +  message);
                    chatOutputStream.flush();
                }
                catch (Exception ex) {
                    //ex.printStackTrace();
                    try {
                        chatOutputStream.writeObject(ip + " is disconnected..");
                    }
                    catch (Exception e) {}

                    System.out.println(ip + " is disconnected..");
                    isConnected = false;
                }
            }

            try {
                chatInputStream.close();
                chatOutputStream.close();
                player1.close();
                player2.close();
            }
            catch (Exception e) {}

            taLog.appendText("Sockets are disconnected\n");

            return;
        }
    }
}
