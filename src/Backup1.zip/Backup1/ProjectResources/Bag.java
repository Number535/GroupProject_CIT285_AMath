package ProjectResources;

import ProjectResources.PlayTiles.*;

import java.util.ArrayList;
import java.util.Collections;

// Bag
// Programmer: Prakrit Saetang
// Last Modified: 9/27/16


public class Bag {
    private ArrayList<PlayTile> playTilesArray;
    
    private static final int AMOUNT = 0;
    private static final int NUMBER = 1;
    private static final int SCORE = 2;

    private static final int[] info0 = new int[] {5, 0, 1};
    private static final int[] info1 = new int[] {6, 1, 1};
    private static final int[] info2 = new int[] {6, 2, 1};
    private static final int[] info3 = new int[] {5, 3, 1};
    private static final int[] info4 = new int[] {5, 4, 2};
    private static final int[] info5 = new int[] {4, 5, 2};
    private static final int[] info6 = new int[] {4, 6, 2};
    private static final int[] info7 = new int[] {4, 7, 2};
    private static final int[] info8 = new int[] {4, 8, 2};
    private static final int[] info9 = new int[] {4, 9, 2};
    private static final int[] info10 = new int[] {2, 10, 3};
    private static final int[] info11 = new int[] {1, 11, 4};
    private static final int[] info12 = new int[] {2, 12, 3};
    private static final int[] info13 = new int[] {1, 13, 6};
    private static final int[] info14 = new int[] {1, 14, 4};
    private static final int[] info15 = new int[] {1, 15, 4};
    private static final int[] info16 = new int[] {1, 16, 4};
    private static final int[] info17 = new int[] {1, 17, 6};
    private static final int[] info18 = new int[] {1, 18, 4};
    private static final int[] info19 = new int[] {1, 19, 7};
    private static final int[] info20 = new int[] {1, 20, 5};
    private static final int[] infoPlus = new int[] {4, 0, 2};
    private static final int[] infoMinus = new int[] {4, 0, 2};
    private static final int[] infoPlusOrMinus = new int[] {5, 0, 1};
    private static final int[] infoMultiply = new int[] {4, 0 , 2};
    private static final int[] infoDivide = new int[] {4, 0, 2};
    private static final int[] infoMultipleOrDivide = new int[] {4, 0, 1};
    private static final int[] infoEqualSign = new int[] {11, 0, 1};
    private static final int[] infoBlank = new int[] {4};

    private static final int[] allNumberAmount = new int[] {
            info0[AMOUNT], info1[AMOUNT], info2[AMOUNT], info3[AMOUNT], info4[AMOUNT], info5[AMOUNT],
            info6[AMOUNT], info7[AMOUNT], info8[AMOUNT], info9[AMOUNT], info10[AMOUNT], info11[AMOUNT],
            info12[AMOUNT], info13[AMOUNT], info14[AMOUNT], info15[AMOUNT], info16[AMOUNT], info17[AMOUNT],
            info18[AMOUNT], info19[AMOUNT], info20[AMOUNT]
    };

    private static final int[] allNumberNumber = new int[] {
            info0[NUMBER], info1[NUMBER], info2[NUMBER], info3[NUMBER], info4[NUMBER], info5[NUMBER],
            info6[NUMBER], info7[NUMBER], info8[NUMBER], info9[NUMBER], info10[NUMBER], info11[NUMBER],
            info12[NUMBER], info13[NUMBER], info14[NUMBER], info15[NUMBER], info16[NUMBER], info17[NUMBER],
            info18[NUMBER], info19[NUMBER], info20[NUMBER]
    };

    private static final int[] allNumberScore = new int[] {
            info0[SCORE], info1[SCORE], info2[SCORE], info3[SCORE], info4[SCORE], info5[SCORE],
            info6[SCORE], info7[SCORE], info8[SCORE], info9[SCORE], info10[SCORE], info11[SCORE],
            info12[SCORE], info13[SCORE], info14[SCORE], info15[SCORE], info16[SCORE], info17[SCORE],
            info18[SCORE], info19[SCORE], info20[SCORE]
    };


    private static final int[] allOperatorAmount = new int[] {
            infoPlus[AMOUNT], infoMinus[AMOUNT],
            infoPlusOrMinus[AMOUNT], infoMultiply[AMOUNT], infoDivide[AMOUNT], infoMultipleOrDivide[AMOUNT],
            infoEqualSign[AMOUNT], infoBlank[AMOUNT]
    };

    Bag() {
        playTilesArray = new ArrayList<>();
        setupBag();
    }

    private void setupBag() {
        for (int i = 0; i < allNumberAmount.length; i++) {
            for (int j = 0; j < allNumberAmount[i]; j++) {
                String tempImageUrl = "Resource/" + String.valueOf(allNumberNumber[i]) + ".png";
                int tempNumber = allNumberNumber[i];
                int tempScore = allNumberScore[i];
                NumberTile tempNumberTile = new NumberTile(tempScore, false, tempImageUrl, tempNumber);
                playTilesArray.add(tempNumberTile);
            }
        }

        for (int i = 0; i < infoBlank[AMOUNT]; i++) {
            BlankTile blankTile = new BlankTile();
            playTilesArray.add(blankTile);
        }

        for (int i = 0; i < infoPlus[AMOUNT]; i++) {
            PlusTile plusTile = new PlusTile();
            playTilesArray.add(plusTile);
        }

        for (int i = 0; i < infoMinus[AMOUNT]; i++) {
            MinusTile minusTile = new MinusTile();
            playTilesArray.add(minusTile);
        }

        for (int i = 0; i < infoPlusOrMinus[AMOUNT]; i++) {
            PlusOrMinusTile plusOrMinusTile = new PlusOrMinusTile();
            playTilesArray.add(plusOrMinusTile);
        }

        for (int i = 0; i < infoMultiply[AMOUNT]; i++) {
            MultiplyTile multiplyTile = new MultiplyTile();
            playTilesArray.add(multiplyTile);
        }

        for (int i = 0; i < infoDivide[AMOUNT]; i++) {
            DivideTile divideTile = new DivideTile();
            playTilesArray.add(divideTile);
        }

        for (int i = 0; i < infoMultipleOrDivide[AMOUNT]; i++) {
            MultipleOrDivideTile multipleOrDivideTile = new MultipleOrDivideTile();
            playTilesArray.add(multipleOrDivideTile);
        }

        for (int i = 0; i < infoEqualSign[AMOUNT]; i++) {
            EqualTile equalTile = new EqualTile();
            playTilesArray.add(equalTile);
        }

        Collections.shuffle(playTilesArray);

        /*
        for (int i = 0; i < playTilesArray.size(); i++) {
            System.out.print(playTilesArray.get(i).toString());
        }
        */
    }


    public PlayTile draw() {
        PlayTile temp = playTilesArray.get(0);
        playTilesArray.remove(0);

        return temp;
    }

    public int getTilesleft() {
        return playTilesArray.size();
    }

    public void returnTiles(PlayTile tile) {
        playTilesArray.add(tile);
        Collections.shuffle(playTilesArray);
    }
}
