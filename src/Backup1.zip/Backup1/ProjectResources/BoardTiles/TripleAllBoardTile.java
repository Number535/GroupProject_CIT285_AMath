package ProjectResources.BoardTiles;

// TripleAllBoardTile
// Programmer: Prakrit Saetang
// Last Modified: 9/23/16

import ProjectResources.BoardTiles.BoardTile;

public class TripleAllBoardTile extends BoardTile {
    int totalScore = -1;

    public int getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(int totalScore) {
        this.totalScore = totalScore;
    }

    public int getScore() {
        return (2 * totalScore);
    }
}
