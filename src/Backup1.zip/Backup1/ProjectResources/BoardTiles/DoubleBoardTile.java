package ProjectResources.BoardTiles;

import ProjectResources.BoardTiles.BoardTile;
import ProjectResources.PlayTiles.PlayTile;

// DoubleBoardTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 9/23/16
public class DoubleBoardTile extends BoardTile {
    @Override
    public int getScore() {
        return playTile.getScore()*2;
    }
}

