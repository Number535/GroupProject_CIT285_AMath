package ProjectResources.BoardTiles;

// StarBoardTile
// Programmer: Prakrit Saetang
// Last Modified: 9/23/16

import ProjectResources.BoardTiles.BoardTile;

public class StarBoardTile extends BoardTile {
    @Override
    public int getScore() {
        return playTile.getScore()*3;
    }


}
