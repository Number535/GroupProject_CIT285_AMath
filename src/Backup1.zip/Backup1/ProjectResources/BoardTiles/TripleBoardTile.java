package ProjectResources.BoardTiles;

import ProjectResources.BoardTiles.BoardTile;

// TripleBoardTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 9/23/16
public class TripleBoardTile extends BoardTile {
    @Override
    public int getScore() {
        return playTile.getScore()*3;
    }
}
