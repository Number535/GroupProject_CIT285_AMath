package ProjectResources;

// AMathConstants
// Programmer: Prakrit Saetang
// Last Modified: 10/27/16

 public interface AMathConstants {
    public static final int PLAYER1 = 1;
    public static final int PLAYER2 = 2;
}
