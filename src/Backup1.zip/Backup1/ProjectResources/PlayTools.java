package ProjectResources;

import ProjectResources.BoardTiles.BoardTile;
import ProjectResources.BoardTiles.StarBoardTile;
import ProjectResources.PlayTiles.NumberTile;
import ProjectResources.PlayTiles.OperatorTile;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// PlayTools
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/26/16
public class PlayTools {
    public boolean isHorizontal(ArrayList<BoardTile> boardTiles, int y) {
        boolean isHorizontal = false;

        for (BoardTile boardTile : boardTiles) {
            if (boardTile.getY() != y) {
                isHorizontal = false;
                break;
            }
            else {
                isHorizontal = true;
            }
        }

        return isHorizontal;
    }

    public boolean isVertical(ArrayList<BoardTile> boardTiles, int x) {
        boolean isVertical = false;

        for (BoardTile boardTile : boardTiles) {
            if (boardTile.getX() != x) {
                isVertical = false;
                break;
            }
            else {
                isVertical = true;
            }
        }

        return isVertical;
    }

    public void sortByY(ArrayList<BoardTile> boardTiles) {
        Collections.sort(boardTiles, new Comparator<BoardTile>() {
            @Override
            public int compare(BoardTile o1, BoardTile o2) {
                return ((Integer)o1.getY()).compareTo(o2.getY());
            }
        });
    }

    public void sortByX(ArrayList<BoardTile> boardTiles) {
        Collections.sort(boardTiles, new Comparator<BoardTile>() {
            @Override
            public int compare(BoardTile o1, BoardTile o2) {
                return ((Integer)o1.getX()).compareTo(o2.getX());
            }
        });
    }

    public String toString(ArrayList<BoardTile> boardTiles) {
        String equation = "";
        for (BoardTile boardTile : boardTiles) {
            if (boardTile.getPlayTile() instanceof NumberTile) {
                String temp;
                temp = String.valueOf(((NumberTile) boardTile.getPlayTile()).getNumber());
                equation += temp;
            }
            else if (boardTile.getPlayTile() instanceof OperatorTile) {
                Character temp;
                temp = ((OperatorTile) boardTile.getPlayTile()).getSign();
                equation += temp;
            }
        }
        return equation;
    }

    public boolean isOnStar(ArrayList<BoardTile> boardTiles) {
        for (BoardTile boardTile : boardTiles) {
            if (boardTile instanceof StarBoardTile)
                return true;
        }
        return false;
    }
}
