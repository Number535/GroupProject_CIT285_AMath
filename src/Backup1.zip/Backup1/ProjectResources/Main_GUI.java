package ProjectResources;
// Main_GUI
// 
// Programmer: Prakrit Saetang
// Last Modified: 9/23/16

import ProjectResources.BoardTiles.BoardTile;
import ProjectResources.PlayTiles.NumberTile;
import ProjectResources.PlayTiles.OperatorTile;
import ProjectResources.PlayTiles.PlayTile;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

public class Main_GUI extends Application implements AMathConstants {

    public static void main(String[] args) {
        launch(args);
    }

    private Socket socket;

    private ObjectInputStream fromServerObject;
    private ObjectOutputStream toServerObject;
    private DataInputStream fromServerData;
    private DataOutputStream toServerData;
    private int numPlayer;
    private Bag bag;
    private OnHandTiles onHandTiles;
    private PlayTools playTools;
    private Board board;

    @Override
    public void start(Stage primaryStage) {

        /*
        Bag bag = new Bag();

        OnHandTiles onHandTiles = new OnHandTiles();
        PlayTools playTools = new PlayTools();

        for (int i = 0; i < 8; i++) {
            PlayTile temp = bag.draw();
            onHandTiles.add(temp);
        }

        Board board = new Board(onHandTiles);
        */
        playTools = new PlayTools();

        TextArea chatRoom = new TextArea();
        chatRoom.setWrapText(true);
        chatRoom.setEditable(false);

        HBox typingArea = new HBox();
        TextField tfTyping = new TextField();
        tfTyping.setPromptText("Type here..");
        tfTyping.setPrefWidth(300);
        Button btTyping = new Button("Send");
        btTyping.setPrefWidth(90);
        typingArea.getChildren().addAll(tfTyping, btTyping);


        Label lbCurrentScore = new Label("Current Score: ");
        Label lbTotalScore = new Label("Total Score: ");
        Label lbTilesLeft = new Label();

        HBox processButtonArea = new HBox();
        processButtonArea.setAlignment(Pos.CENTER);
        processButtonArea.setSpacing(20);
        Button btSubmit = new Button("Submit");
        btSubmit.setPrefWidth(150);
        Button btChangeTiles = new Button("Change PlayTiles");
        btChangeTiles.setPrefWidth(150);
        processButtonArea.getChildren().addAll(btSubmit, btChangeTiles);


        VBox rightPane = new VBox();
        rightPane.setSpacing(10);
        rightPane.setPadding(new Insets(20, 10, 10, 10));
        rightPane.setPrefHeight(600);
        rightPane.setPrefWidth(400);
        rightPane.setId("rightPane");
        rightPane.getChildren().addAll(chatRoom, typingArea, lbCurrentScore, lbTotalScore, lbTilesLeft, processButtonArea);

        VBox leftPane = new VBox();


        HBox mainPane = new HBox();
        mainPane.getChildren().addAll(leftPane, rightPane);

        double leftPaneWidth = new Board(new OnHandTiles()).getBoardPane().getPrefWidth();
        //double leftPaneHeight = new Board(new OnHandTiles()).getBoardPane().getPrefHeight();

        Scene scene = new Scene(mainPane, leftPaneWidth + rightPane.getPrefWidth(), rightPane.getPrefHeight());
        scene.getStylesheets().add(getClass().getResource("Resource/StyleSheet.css").toString());
        primaryStage.setTitle("A - math");
        primaryStage.setScene(scene);
        primaryStage.show();

        tfTyping.setOnAction(event -> {
            if (!tfTyping.getText().equals("")) {
                try {
                    String message = tfTyping.getText();
                    toServerObject.writeObject(message);
                    toServerObject.flush();
                    Platform.runLater(() -> {
                        tfTyping.setText("");
                        chatRoom.appendText("Me: " + message + "\n");
                    });
                }
                catch (Exception ex) {}
            }
        });

        btTyping.setOnAction(event -> {
            if (!tfTyping.getText().equals("")) {
                try {
                    String message = tfTyping.getText();
                    toServerObject.writeObject(message);
                    toServerObject.flush();
                    Platform.runLater(() -> {
                        tfTyping.setText("");
                        chatRoom.appendText("Me: " + message + "\n");
                    });
                }
                catch (Exception ex) {}
            }
        });

        btSubmit.setOnAction(event -> {
            ResultFinder resultFinder;
            String equation = "";

            ArrayList<BoardTile> onUsedBoardTile = board.getUsedBoardTile();

            int x = onUsedBoardTile.get(0).getX(), y = onUsedBoardTile.get(0).getY();

            if (!playTools.isOnStar(onUsedBoardTile)) {
                showErrorAlert("Invalid Input");
                return;
            }

            if (playTools.isHorizontal(onUsedBoardTile, y)) {
                playTools.sortByX(onUsedBoardTile);
            }
            else if (playTools.isVertical(onUsedBoardTile, x)) {
                playTools.sortByY(onUsedBoardTile);
            }
            else {
                showErrorAlert("Invalid Input");
                return;
            }


            equation = playTools.toString(onUsedBoardTile);

            System.out.println(equation);

            resultFinder = new ResultFinder(equation);
            System.out.println(resultFinder.getResult());
        });

        btChangeTiles.setOnAction(event -> {
            onHandTiles.clearUsed();
            ChangeTile changeTile = new ChangeTile();
            changeTile.display(onHandTiles, bag);
        });


        //==================================[ CONNECTION ]=======================================

        try {
            socket = new Socket("localhost", 2705);
            //fromServerObject = new ObjectInputStream(socket.getInputStream());
            //toServerObject = new ObjectOutputStream(socket.getOutputStream());
            fromServerObject = new ObjectInputStream(socket.getInputStream());
            toServerObject = new ObjectOutputStream(socket.getOutputStream());
            fromServerData = new DataInputStream(socket.getInputStream());
            toServerData = new DataOutputStream(socket.getOutputStream());
            chatRoom.appendText("You are connected\n");

            numPlayer = fromServerData.readInt();
            System.out.println(numPlayer);


        }
        catch (Exception ex) {}

        new Thread(() -> {
            try {
                String notifyPlayerNum = fromServerObject.readObject().toString();
                Platform.runLater(() -> {
                    chatRoom.appendText(notifyPlayerNum + "\n");
                });

                onHandTiles = new OnHandTiles();

                if (numPlayer == PLAYER1) {
                    String notifyWaitForPlayer2 = fromServerObject.readObject().toString();
                    Platform.runLater(() -> {
                        chatRoom.appendText(notifyWaitForPlayer2 + "\n");

                        bag = new Bag();
                        board = new Board(onHandTiles);
                        leftPane.getChildren().add(board.getBoardPane());

                        for (int i = 0; i < 8; i++) {
                            PlayTile temp = bag.draw();
                            onHandTiles.add(temp);
                        }

                        lbTilesLeft.setText("PlayTiles left: " + bag.getTilesleft());
                        rightPane.getChildren().clear();
                        rightPane.getChildren().addAll(chatRoom, typingArea, lbCurrentScore,
                                lbTotalScore, lbTilesLeft, processButtonArea, onHandTiles.getPane());

                    });

                    CommunicatePackage communicatePackage = new CommunicatePackage(board, bag);
                    toServerObject.writeObject(bag);
                }
                else if (numPlayer == PLAYER2) {
                    CommunicatePackage communicatePackage = (CommunicatePackage) fromServerObject.readObject();
                    Platform.runLater(() -> {
                        System.out.println(communicatePackage.getBag().getTilesleft());
                        bag = communicatePackage.getBag();
                        board = communicatePackage.getBoard();

                        leftPane.getChildren().add(board.getBoardPane());

                        for (int i = 0; i < 8; i++) {
                            PlayTile temp = bag.draw();
                            onHandTiles.add(temp);
                        }

                        lbTilesLeft.setText("PlayTiles left: " + bag.getTilesleft());
                        rightPane.getChildren().clear();
                        rightPane.getChildren().addAll(chatRoom, typingArea, lbCurrentScore,
                                lbTotalScore, lbTilesLeft, processButtonArea, onHandTiles.getPane());
                    });
                }

                //
                //mainPane.getChildren().addAll(board.getBoardPane(), rightPane);


                String notifyGameStarted = fromServerObject.readObject().toString();
                Platform.runLater(() -> {
                    chatRoom.appendText(notifyGameStarted + "\n");
                });

                new Thread(() -> {
                    while (true) {
                        try {
                            String message = fromServerObject.readObject().toString();
                            System.out.println("Receive: " +  message);
                            Platform.runLater(() -> {
                                chatRoom.appendText(message + "\n");
                            });
                        }
                        catch (Exception ex) {}
                    }
                }).start();

            }
            catch (Exception ex) {

            }
        }).start();


    }

    private void showErrorAlert(String string) {
        Alert alert = new Alert(Alert.AlertType.ERROR, string);
        alert.setResizable(false);
        alert.show();
    }
}
