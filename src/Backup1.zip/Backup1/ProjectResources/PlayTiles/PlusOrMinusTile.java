package ProjectResources.PlayTiles;

// PlusOrMinusTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/6/16
public class PlusOrMinusTile extends PlayTile {

    public PlusOrMinusTile() {
        setTileImage("Resource/+or-.png");
    }
}
