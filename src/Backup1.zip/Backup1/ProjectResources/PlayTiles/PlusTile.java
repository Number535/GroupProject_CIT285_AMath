package ProjectResources.PlayTiles;

import ProjectResources.PlayTiles.PlayTile;

// OperatorTile
// Programmer: Prakrit Saetang
// Last Modified: 9/29/16

public class PlusTile extends OperatorTile {

    public PlusTile() {
        sign = '+';
        setTileImage("Resource/+.png");
    }
}
