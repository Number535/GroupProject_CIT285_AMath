package ProjectResources.PlayTiles;

// MultipleOrDivideTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/6/16
public class MultipleOrDivideTile extends PlayTile {

    public MultipleOrDivideTile() {
        setTileImage("Resource/multipleOrDivide.png");
    }

}
