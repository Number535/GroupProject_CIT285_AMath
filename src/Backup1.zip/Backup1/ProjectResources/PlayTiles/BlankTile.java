package ProjectResources.PlayTiles;

// BlankTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/6/16
public class BlankTile extends PlayTile {
    public BlankTile() {
        setTileImage("Resource/blankPlay.png");
        setScore(0);
    }
}
