package ProjectResources.PlayTiles;

// MinusTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/6/16
public class MinusTile extends OperatorTile {

    public MinusTile() {
        sign = '-';
        setTileImage("Resource/-.png");
    }

}
