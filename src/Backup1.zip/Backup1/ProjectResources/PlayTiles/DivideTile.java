package ProjectResources.PlayTiles;

// DivideTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/6/16
public class DivideTile extends OperatorTile {
    public DivideTile() {
        sign = '/';
        setTileImage("Resource/divide.png");
    }
}
