package ProjectResources.PlayTiles;

// OperatorTile
// 
// Programmer: Prakrit Saetang
// Last Modified: 10/7/16
public class OperatorTile extends PlayTile {
    protected Character sign;

    public Character getSign() {
        return sign;
    }
}
