package ProjectResources.PlayTiles;

// PlayTile
// Programmer: Prakrit Saetang
// Last Modified: 9/20/16

import javafx.scene.image.Image;

public class PlayTile {
    protected int score;        // to hold a score on a play tile
    protected boolean isUsed;   // to tell if a tile is used
    protected Image tileImage;  // to hold an image object of a tile

    // constructor
    public PlayTile() {
        this.score = -1;
        this.isUsed = false;
        this.tileImage = null;
    }

    public PlayTile(int score, boolean isUsed, String tileImageUrl) {
        this.score = score;
        this.isUsed = isUsed;
        this.tileImage = new Image(getClass().getResourceAsStream(tileImageUrl));
    }

    // Getters
    public int getScore() {
        return score;
    }

    public boolean isUsed() {
        return isUsed;
    }

    public Image getTileImage() {
        return tileImage;
    }

    // Setters
    public void setScore(int score) {
        this.score = score;
    }

    public void setUsed(boolean used) {
        isUsed = used;
    }

    public void setTileImage(String tileImageUrl) {
        this.tileImage = new Image(getClass().getResourceAsStream(tileImageUrl));
    }
}
